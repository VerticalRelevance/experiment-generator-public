def a_func(i:dict,j:dict,k:int):
    print(i)
