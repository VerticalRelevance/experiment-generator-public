def hello(name: str):
    print(f"hello {name}")