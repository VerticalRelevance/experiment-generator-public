def atest(x:int, y:int):
    return x+y/x

def another(b,c):
    return b-c
